export default /* glsl */`
#ifdef USE_ALPHAMAP

	uniform sampler2D alphaMap;

#endif
`;
